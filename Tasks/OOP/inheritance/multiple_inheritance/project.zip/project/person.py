class Person:
    def sleep(self):
        return f"sleeping..."